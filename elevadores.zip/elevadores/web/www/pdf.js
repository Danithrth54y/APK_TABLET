/*
 * Generador de PDF mínimo, sin librerías (funciona sin internet).
 * Hace una página A4 apaisada con la imagen del formulario de fondo y, encima,
 * las marcas de las casillas y los textos escritos en su sitio.
 */
const Pdf = (() => {
  const ANCHO_PAGINA = 841.89; // A4 apaisado, en puntos
  const ALTO_PAGINA = 595.28;
  const COLOR_TINTA = '0.05 0.16 0.42'; // azul oscuro, como un bolígrafo

  // Anchos de Helvetica (de 32 a 126), en milésimas del tamaño de letra.
  const ANCHOS = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
    556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667,
    722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722,
    667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556,
    222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334,
    260, 334, 584];
  const ESPECIALES = { '€': 128, '…': 133, '‘': 145, '’': 146, '“': 147, '”': 148, '–': 150, '—': 151 };

  const ancho = (texto, tam) => {
    let total = 0;
    for (const c of texto) {
      const base = c.normalize('NFD')[0];
      const k = base.charCodeAt(0);
      total += (k >= 32 && k <= 126) ? ANCHOS[k - 32] : 556;
    }
    return total * tam / 1000;
  };

  // Texto a bytes WinAnsi, dentro de ( ) con los caracteres especiales escapados.
  const cadena = (texto) => {
    const bytes = [40];
    for (const c of texto) {
      let k = c.charCodeAt(0);
      if (ESPECIALES[c] !== undefined) k = ESPECIALES[c];
      else if (k > 255 || (k > 126 && k < 160) || k < 32) k = 63; // ?
      if (k === 40 || k === 41 || k === 92) bytes.push(92);
      bytes.push(k);
    }
    bytes.push(41);
    return bytes;
  };

  const num = (n) => (Math.round(n * 100) / 100).toString();

  // Tamaño y número de componentes de color de un JPEG (marcador SOF).
  const datosJpeg = (b) => {
    if (b[0] !== 0xFF || b[1] !== 0xD8) throw new Error('La imagen de fondo no es un JPEG.');
    let i = 2;
    while (i < b.length) {
      if (b[i] !== 0xFF) { i++; continue; }
      const m = b[i + 1];
      const largo = (b[i + 2] << 8) | b[i + 3];
      if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) {
        return { alto: (b[i + 5] << 8) | b[i + 6], ancho: (b[i + 7] << 8) | b[i + 8], componentes: b[i + 9] };
      }
      i += 2 + largo;
    }
    throw new Error('No se ha podido leer el tamaño de la imagen.');
  };

  // Parte un texto en líneas que quepan en el ancho dado.
  const lineas = (texto, tam, max) => {
    const salida = [];
    for (const parrafo of texto.split(/\r?\n/)) {
      let actual = '';
      for (const palabra of parrafo.split(/\s+/).filter(Boolean)) {
        const prueba = actual ? actual + ' ' + palabra : palabra;
        if (!actual || ancho(prueba, tam) <= max) actual = prueba;
        else { salida.push(actual); actual = palabra; }
      }
      salida.push(actual);
    }
    return salida;
  };

  function dibujarTexto(partes, texto, r, multilinea) {
    const margen = Math.min(r.w, r.h) * 0.12;
    const maxAncho = r.w - 2 * margen;
    let tam, filas;
    if (multilinea) {
      tam = Math.min(9, r.h * 0.4);
      for (; tam > 4; tam -= 0.5) {
        filas = lineas(texto, tam, maxAncho);
        if (filas.length * tam * 1.2 <= r.h - 2 * margen && filas.every((f) => ancho(f, tam) <= maxAncho)) break;
      }
      filas = lineas(texto, tam, maxAncho);
    } else {
      tam = Math.min(r.h * 0.72, 12);
      while (tam > 4 && ancho(texto, tam) > maxAncho) tam -= 0.5;
      filas = [texto];
    }
    const altoBloque = filas.length * tam * 1.2;
    let y = r.y + (r.h + altoBloque) / 2 - tam * 0.95;
    for (const f of filas) {
      partes.push(`BT /F1 ${num(tam)} Tf ${num(r.x + margen)} ${num(y)} Td `);
      partes.push(cadena(f));
      partes.push(' Tj ET\n');
      y -= tam * 1.2;
    }
  }

  /**
   * imagen: Uint8Array con el JPEG de fondo; campos: los de config.json; valores: {id: true | 'texto'}.
   * Devuelve un Uint8Array con el PDF.
   */
  function crear({ imagen, campos, valores, titulo }) {
    const jpg = datosJpeg(imagen);
    const escala = Math.min(ANCHO_PAGINA / jpg.ancho, ALTO_PAGINA / jpg.alto);
    const iw = jpg.ancho * escala, ih = jpg.alto * escala;
    const ox = (ANCHO_PAGINA - iw) / 2, oy = (ALTO_PAGINA - ih) / 2;
    const rect = (c) => ({ x: ox + c.x * iw, y: oy + (1 - c.y - c.h) * ih, w: c.w * iw, h: c.h * ih });

    // Contenido de la página
    const partes = [`q ${num(iw)} 0 0 ${num(ih)} ${num(ox)} ${num(oy)} cm /Fondo Do Q\n`,
      `${COLOR_TINTA} RG ${COLOR_TINTA} rg 1 J 1 j\n`];
    for (const c of campos) {
      const v = valores[c.id];
      if (!v) continue;
      const r = rect(c);
      if (c.tipo === 'check') {
        partes.push(`${num(Math.max(0.8, r.h * 0.16))} w ` +
          `${num(r.x + r.w * 0.16)} ${num(r.y + r.h * 0.52)} m ` +
          `${num(r.x + r.w * 0.42)} ${num(r.y + r.h * 0.22)} l ` +
          `${num(r.x + r.w * 0.9)} ${num(r.y + r.h * 0.9)} l S\n`);
      } else if (String(v).trim()) {
        dibujarTexto(partes, String(v).trim(), r, c.tipo === 'multilinea');
      }
    }
    const contenido = aBytes(partes);

    const espacio = jpg.componentes === 4 ? '/DeviceCMYK' : jpg.componentes === 1 ? '/DeviceGray' : '/DeviceRGB';
    const objetos = [
      aBytes(['<< /Type /Catalog /Pages 2 0 R >>']),
      aBytes(['<< /Type /Pages /Kids [3 0 R] /Count 1 >>']),
      aBytes([`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${ANCHO_PAGINA} ${ALTO_PAGINA}] ` +
        '/Resources << /XObject << /Fondo 5 0 R >> /Font << /F1 6 0 R >> >> /Contents 4 0 R >>']),
      aBytes([`<< /Length ${contenido.length} >>\nstream\n`, contenido, '\nendstream']),
      aBytes([`<< /Type /XObject /Subtype /Image /Width ${jpg.ancho} /Height ${jpg.alto} /ColorSpace ${espacio} ` +
        `/BitsPerComponent 8 /Filter /DCTDecode${jpg.componentes === 4 ? ' /Decode [1 0 1 0 1 0 1 0]' : ''} ` +
        `/Length ${imagen.length} >>\nstream\n`, imagen, '\nendstream']),
      aBytes(['<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>']),
      aBytes(['<< /Title ', cadena(titulo || 'Check-list'), ' /Producer (Check-list elevadores) >>']),
    ];

    const trozos = [aBytes(['%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n'.split('').map((c) => c.charCodeAt(0))])];
    let posicion = trozos[0].length;
    const desplazamientos = [];
    objetos.forEach((o, i) => {
      desplazamientos.push(posicion);
      const t = aBytes([`${i + 1} 0 obj\n`, o, '\nendobj\n']);
      trozos.push(t);
      posicion += t.length;
    });
    let xref = `xref\n0 ${objetos.length + 1}\n0000000000 65535 f \n`;
    for (const d of desplazamientos) xref += `${String(d).padStart(10, '0')} 00000 n \n`;
    xref += `trailer\n<< /Size ${objetos.length + 1} /Root 1 0 R /Info 7 0 R >>\nstartxref\n${posicion}\n%%EOF\n`;
    trozos.push(aBytes([xref]));
    return unir(trozos);
  }

  // Une textos (ASCII), listas de bytes y Uint8Array en un solo Uint8Array.
  function aBytes(partes) {
    const listas = partes.map((p) => {
      if (p instanceof Uint8Array) return p;
      if (Array.isArray(p)) return Uint8Array.from(p);
      const s = String(p);
      const b = new Uint8Array(s.length);
      for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xFF;
      return b;
    });
    return unir(listas);
  }

  function unir(listas) {
    const total = listas.reduce((n, l) => n + l.length, 0);
    const salida = new Uint8Array(total);
    let i = 0;
    for (const l of listas) { salida.set(l, i); i += l.length; }
    return salida;
  }

  return { crear, datosJpeg };
})();
