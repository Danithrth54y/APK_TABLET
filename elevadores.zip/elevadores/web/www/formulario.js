/*
 * Check-list de elevadores: dibuja los campos de formularios/<f>/config.json sobre su imagen de fondo,
 * guarda lo escrito automáticamente y genera el PDF.
 *
 * Funciona igual en el ordenador (con ServidorLocal.java) y en la APK (con el puente
 * AndroidBackend de MainActivity.java). Lo único que cambia es "Servidor", abajo.
 */
(() => {
  'use strict';

  // ---------------------------------------------------------------- Servidor (Java)
  // En la APK existe window.AndroidBackend; en el ordenador se habla con ServidorLocal.java.
  const Servidor = window.AndroidBackend ? {
    cargar: async (id) => window.AndroidBackend.cargar(id),
    guardar: async (id, texto) => window.AndroidBackend.guardar(id, texto),
    guardarArchivo: async (carpeta, nombre, mime, base64) =>
      window.AndroidBackend.guardarArchivo(carpeta, nombre, mime, base64),
  } : {
    cargar: async (id) => {
      const r = await fetch('api/borrador?id=' + encodeURIComponent(id));
      return r.ok ? r.text() : '';
    },
    guardar: async (id, texto) => {
      const r = await fetch('api/borrador?id=' + encodeURIComponent(id), { method: 'POST', body: texto });
      return r.ok;
    },
    guardarArchivo: async (carpeta, nombre, mime, base64) => {
      const r = await fetch('api/archivo?carpeta=' + encodeURIComponent(carpeta) + '&nombre=' + encodeURIComponent(nombre) +
        '&mime=' + encodeURIComponent(mime), { method: 'POST', body: base64 });
      return r.text();
    },
  };

  // ---------------------------------------------------------------- Estado
  const $ = (id) => document.getElementById(id);
  const hoja = $('hoja'), fondo = $('fondo'), capa = $('campos');
  const PARAMETROS = new URLSearchParams(location.search);
  const EDITOR = PARAMETROS.get('editor') === '1';
  const FORMULARIO = (PARAMETROS.get('f') || '').replace(/[^A-Za-z0-9_-]/g, '');
  const BASE = 'formularios/' + FORMULARIO + '/'; // config.json y la imagen de este formulario
  // Nº del elevador (?n=1): cada elevador tiene su propia hoja en curso y su número ya puesto.
  const NUMERO = (PARAMETROS.get('n') || '').replace(/[^A-Za-z0-9-]/g, '');
  const idBorrador = () => config.id + (NUMERO ? '_n' + NUMERO : '');
  const valoresIniciales = () => (NUMERO ? { numero_elevador: NUMERO } : {});
  const TOQUE = 2.2; // la zona que se toca de una casilla es 2,2 veces el cuadro dibujado
  let config = null;
  let valores = {};
  const elementos = {}; // id -> elemento en pantalla

  const ahora = () => new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  const estado = (texto) => { $('estado').textContent = texto; };

  // ---------------------------------------------------------------- Avisos
  // conCancelar: muestra Cancelar. entrada: texto inicial de un campo para escribir; entonces devuelve lo
  // escrito (o null si se cancela).
  function aviso(texto, conCancelar = false, entrada = null) {
    return new Promise((resolver) => {
      $('aviso-texto').textContent = texto;
      $('aviso-cancelar').hidden = !conCancelar;
      $('aviso-campo').hidden = entrada === null;
      $('aviso-entrada').value = entrada || '';
      $('aviso').hidden = false;
      const cerrar = (respuesta) => {
        $('aviso').hidden = true;
        $('aviso-aceptar').onclick = $('aviso-cancelar').onclick = $('aviso-entrada').onkeydown = null;
        resolver(entrada === null ? respuesta : (respuesta ? $('aviso-entrada').value : null));
      };
      $('aviso-aceptar').onclick = () => cerrar(true);
      $('aviso-cancelar').onclick = () => cerrar(false);
      $('aviso-entrada').onkeydown = (e) => { if (e.key === 'Enter') cerrar(true); };
      (entrada === null ? $('aviso-aceptar') : $('aviso-entrada')).focus();
    });
  }

  // ---------------------------------------------------------------- Campos
  const SVG_MARCA = '<svg viewBox="0 0 10 10" aria-hidden="true"><path d="M1.6 5.2 L4.2 7.8 L9 2" ' +
    'fill="none" stroke="#0d2a6b" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function crearCampo(c) {
    let el;
    if (c.tipo === 'check') {
      el = document.createElement('div');
      el.className = 'casilla';
      el.setAttribute('role', 'checkbox');
      el.setAttribute('tabindex', '0');
      el.setAttribute('aria-checked', 'false');
      el.setAttribute('aria-label', c.id);
      el.innerHTML = '<span class="marca">' + SVG_MARCA + '</span>';
      const alternar = () => {
        if (EDITOR) return;
        const nuevo = el.getAttribute('aria-checked') !== 'true';
        el.setAttribute('aria-checked', String(nuevo));
        cambiar(c.id, nuevo);
        // Excluyentes (OK / DEFECTO del mismo día, los tres turnos): al marcar una, se desmarcan las demás.
        if (nuevo && c.excluye) {
          for (const otra of config.campos) {
            if (otra !== c && otra.excluye === c.excluye && valores[otra.id]) {
              elementos[otra.id].setAttribute('aria-checked', 'false');
              cambiar(otra.id, false);
            }
          }
        }
      };
      el.addEventListener('click', alternar);
      el.addEventListener('keydown', (e) => {
        if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); alternar(); }
      });
    } else {
      el = document.createElement(c.tipo === 'multilinea' ? 'textarea' : 'input');
      if (c.tipo !== 'multilinea') el.type = 'text';
      el.className = 'campo-texto';
      el.setAttribute('aria-label', c.id);
      el.autocomplete = 'off';
      el.spellcheck = false;
      el.addEventListener('input', () => cambiar(c.id, el.value));
    }
    el.id = 'campo_' + c.id;
    el.dataset.id = c.id;
    colocar(el, c);
    capa.appendChild(el);
    elementos[c.id] = el;
  }

  // Sitúa un campo en porcentajes de la imagen (así vale para cualquier tamaño de pantalla).
  function colocar(el, c) {
    if (c.tipo === 'check') {
      const w = c.w * TOQUE, h = c.h * TOQUE;
      Object.assign(el.style, {
        left: (c.x - (w - c.w) / 2) * 100 + '%', top: (c.y - (h - c.h) / 2) * 100 + '%',
        width: w * 100 + '%', height: h * 100 + '%',
      });
      const m = el.firstChild;
      const borde = (1 - 1 / TOQUE) / 2 * 100 + '%';
      Object.assign(m.style, { left: borde, top: borde, width: 100 / TOQUE + '%', height: 100 / TOQUE + '%' });
    } else {
      Object.assign(el.style, { left: c.x * 100 + '%', top: c.y * 100 + '%', width: c.w * 100 + '%', height: c.h * 100 + '%' });
    }
  }

  // El tamaño de letra sigue al de la hoja en pantalla.
  function ajustarLetra() {
    const altoHoja = hoja.clientHeight;
    for (const c of config.campos) {
      if (c.tipo === 'check') continue;
      const alto = c.h * altoHoja;
      elementos[c.id].style.fontSize = (c.tipo === 'multilinea' ? Math.min(alto * 0.3, altoHoja * 0.016)
        : alto * 0.72) + 'px';
    }
  }

  function mostrarValores() {
    for (const c of config.campos) {
      const el = elementos[c.id];
      if (c.tipo === 'check') el.setAttribute('aria-checked', String(!!valores[c.id]));
      else el.value = valores[c.id] || '';
    }
  }

  // ---------------------------------------------------------------- Guardado automático
  let temporizador = null;
  function cambiar(id, valor) {
    if (valor === false || valor === '') delete valores[id];
    else valores[id] = valor;
    estado('Guardando…');
    clearTimeout(temporizador);
    temporizador = setTimeout(guardarBorrador, 400);
  }

  async function guardarBorrador() {
    clearTimeout(temporizador);
    try {
      const ok = await Servidor.guardar(idBorrador(),
        JSON.stringify({ formulario: idBorrador(), guardado: new Date().toISOString(), valores }));
      estado(ok === false ? '⚠ No se ha podido guardar' : 'Guardado ' + ahora());
    } catch (e) {
      estado('⚠ No se ha podido guardar');
    }
  }

  async function cargarBorrador() {
    try {
      const texto = await Servidor.cargar(idBorrador());
      if (!texto) return;
      const datos = JSON.parse(texto);
      if (datos.formulario === idBorrador() && datos.valores) valores = datos.valores;
    } catch (e) {
      console.warn('Borrador no válido:', e);
    }
  }

  // ---------------------------------------------------------------- PDF
  async function bytesImagen() {
    const r = await fetch(BASE + config.imagen);
    const b = new Uint8Array(await r.arrayBuffer());
    if (b[0] === 0xFF && b[1] === 0xD8) return b;
    // Si la imagen no es JPEG (por ejemplo PNG), se convierte.
    const lienzo = document.createElement('canvas');
    lienzo.width = fondo.naturalWidth;
    lienzo.height = fondo.naturalHeight;
    const ctx = lienzo.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, lienzo.width, lienzo.height);
    ctx.drawImage(fondo, 0, 0);
    const blob = await new Promise((ok) => lienzo.toBlob(ok, 'image/jpeg', 0.92));
    return new Uint8Array(await blob.arrayBuffer());
  }

  function aBase64(bytes) {
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  const limpiar = (t) => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30);

  // Nombre propuesto para el PDF, según "nombrePdf" de config.json: {numero_elevador} se cambia por lo
  // escrito en ese campo. Lo que esté vacío desaparece sin dejar guiones bajos sueltos.
  function nombrePropuesto() {
    const plantilla = config.nombrePdf || (config.id + '_{semana_desde}');
    return plantilla.replace(/\{([A-Za-z0-9_]+)\}/g, (_, id) => limpiar(valores[id]))
      .replace(/_+/g, '_').replace(/^_|_$/g, '');
  }

  const nombreValido = (t) => String(t || '').trim().replace(/\.pdf$/i, '').normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^[._]+/, '').slice(0, 120);

  async function guardarPdf() {
    const boton = $('btn-pdf');
    boton.disabled = true;
    try {
      await guardarBorrador();
      let nombre = await aviso('Nombre del PDF (se puede cambiar):', true, nombrePropuesto());
      if (nombre === null) return;
      nombre = nombreValido(nombre);
      if (!nombre) { await aviso('Escriba un nombre para el PDF.'); return; }
      const bytes = Pdf.crear({ imagen: await bytesImagen(), campos: config.campos, valores, titulo: config.titulo });
      const respuesta = await Servidor.guardarArchivo(config.carpeta || FORMULARIO, nombre + '.pdf', 'application/pdf',
        aBase64(bytes));
      if (String(respuesta).startsWith('ERROR')) throw new Error(String(respuesta).replace(/^ERROR:?\s*/, ''));
      await aviso('PDF guardado:\n' + respuesta);
    } catch (e) {
      await aviso('No se ha podido guardar el PDF.\n' + (e.message || e));
    } finally {
      boton.disabled = false;
    }
  }

  async function nuevoFormulario() {
    const si = await aviso('¿Vaciar el formulario para empezar uno nuevo?\nLo que no esté guardado en PDF se perderá.', true);
    if (!si) return;
    valores = valoresIniciales();
    mostrarValores();
    await guardarBorrador();
  }

  // ---------------------------------------------------------------- Modo ajuste (?editor=1)
  // Para recolocar los campos sobre una imagen nueva sin tocar el código.
  function activarEditor() {
    $('barra-editor').hidden = false;
    hoja.classList.add('ajustando');
    for (const el of Object.values(elementos)) {
      if (el.tagName !== 'DIV') el.readOnly = true;
      el.tabIndex = -1;
    }
    const porId = Object.fromEntries(config.campos.map((c) => [c.id, c]));
    let seleccionado = null;
    const afectados = () => {
      if (!seleccionado) return [];
      return $('mover-grupo').checked && seleccionado.grupo
        ? config.campos.filter((c) => c.grupo === seleccionado.grupo) : [seleccionado];
    };
    const marcar = () => {
      for (const el of Object.values(elementos)) el.classList.remove('seleccionado', 'del-grupo');
      if (!seleccionado) { $('seleccion').textContent = ''; return; }
      for (const c of afectados()) elementos[c.id].classList.add('del-grupo');
      elementos[seleccionado.id].classList.add('seleccionado');
      const s = seleccionado;
      $('seleccion').textContent = `${s.id} (${s.grupo || 'sin grupo'}) · x ${s.x.toFixed(4)} y ${s.y.toFixed(4)} ` +
        `w ${s.w.toFixed(4)} h ${s.h.toFixed(4)}`;
    };
    $('mover-grupo').addEventListener('change', marcar);
    const redondear = (c) => { for (const k of ['x', 'y', 'w', 'h']) c[k] = Math.round(c[k] * 100000) / 100000; };
    const mover = (dx, dy) => {
      for (const c of afectados()) { c.x += dx; c.y += dy; redondear(c); colocar(elementos[c.id], c); }
      marcar();
    };

    capa.addEventListener('pointerdown', (e) => {
      const el = e.target.closest('[data-id]');
      if (!el) return;
      e.preventDefault();
      seleccionado = porId[el.dataset.id];
      marcar();
      const ancho = hoja.clientWidth, alto = hoja.clientHeight;
      let ultimoX = e.clientX, ultimoY = e.clientY;
      const alMover = (m) => {
        mover((m.clientX - ultimoX) / ancho, (m.clientY - ultimoY) / alto);
        ultimoX = m.clientX; ultimoY = m.clientY;
      };
      const alSoltar = () => {
        window.removeEventListener('pointermove', alMover);
        window.removeEventListener('pointerup', alSoltar);
      };
      window.addEventListener('pointermove', alMover);
      window.addEventListener('pointerup', alSoltar);
    });

    window.addEventListener('keydown', (e) => {
      if (!seleccionado || !e.key.startsWith('Arrow')) return;
      e.preventDefault();
      const paso = (e.shiftKey ? 10 : 1);
      const px = paso / fondo.naturalWidth, py = paso / fondo.naturalHeight;
      const dx = e.key === 'ArrowLeft' ? -px : e.key === 'ArrowRight' ? px : 0;
      const dy = e.key === 'ArrowUp' ? -py : e.key === 'ArrowDown' ? py : 0;
      if (e.ctrlKey || e.metaKey) {
        for (const c of afectados()) {
          c.w = Math.max(px, c.w + dx); c.h = Math.max(py, c.h + dy); redondear(c); colocar(elementos[c.id], c);
        }
        ajustarLetra();
        marcar();
      } else {
        mover(dx, dy);
      }
    });

    $('btn-exportar').addEventListener('click', async () => {
      const lineas = config.campos.map((c) => '  ' + JSON.stringify(c));
      const cabecera = Object.entries(config).filter(([k]) => k !== 'campos')
        .map(([k, v]) => ` ${JSON.stringify(k)}: ${JSON.stringify(v)},`);
      const texto = '{\n' + cabecera.join('\n') + '\n "campos": [\n' + lineas.join(',\n') + '\n ]\n}\n';
      const bytes = new TextEncoder().encode(texto);
      const respuesta = await Servidor.guardarArchivo('config_' + FORMULARIO, 'config.json', 'application/json',
        aBase64(bytes));
      await aviso('config.json exportado:\n' + respuesta +
        '\n\nCópielo a web/www/formularios/' + FORMULARIO + ' para que la aplicación lo use.');
    });
  }

  // ---------------------------------------------------------------- Arranque
  async function iniciar() {
    try {
      const r = await fetch(BASE + 'config.json', { cache: 'no-store' });
      config = await r.json();
    } catch (e) {
      if (!FORMULARIO) { location.href = 'index.html'; return; }
      $('titulo').textContent = 'No se encuentra el formulario ' + FORMULARIO;
      return;
    }
    const titulo = NUMERO ? 'Elevador ' + NUMERO + ' · ' + config.titulo : config.titulo;
    document.title = titulo;
    $('titulo').textContent = titulo;
    await new Promise((ok, mal) => {
      fondo.onload = ok;
      fondo.onerror = () => mal(new Error('No se encuentra la imagen ' + config.imagen));
      fondo.src = BASE + config.imagen;
    }).catch((e) => aviso(e.message));
    config.campos.forEach(crearCampo);
    await cargarBorrador();
    if (NUMERO && elementos.numero_elevador) {
      valores.numero_elevador = NUMERO; // el número viene dado por el elevador elegido
      elementos.numero_elevador.readOnly = true;
    }
    mostrarValores();
    ajustarLetra();
    new ResizeObserver(ajustarLetra).observe(hoja);
    $('btn-pdf').addEventListener('click', guardarPdf);
    $('btn-nuevo').addEventListener('click', nuevoFormulario);
    document.addEventListener('visibilitychange', () => { if (document.hidden) guardarBorrador(); });
    estado(Object.keys(valores).length > Object.keys(valoresIniciales()).length ? 'Recuperado lo guardado' : '');
    if (EDITOR) activarEditor();
  }

  iniciar();
})();
