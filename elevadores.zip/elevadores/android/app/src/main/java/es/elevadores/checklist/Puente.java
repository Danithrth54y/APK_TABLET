package es.elevadores.checklist;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * La parte Java que usa la página (window.AndroidBackend): guarda y recupera el borrador de cada formulario y
 * guarda los PDF en Documentos/Elevadores/<carpeta> (2_columnas, 4_columnas), donde se ven al conectar la
 * tableta al ordenador por USB. Hace lo mismo que escritorio/ServidorLocal.java en el ordenador.
 */
public class Puente {

    private static final String CARPETA = "Elevadores";
    private final Context contexto;

    public Puente(Context contexto) {
        this.contexto = contexto.getApplicationContext();
    }

    /** Borrador guardado del formulario, o "" si no hay. */
    @JavascriptInterface
    public String cargar(String id) {
        File fichero = borrador(id);
        if (!fichero.isFile()) {
            return "";
        }
        try (InputStream in = new FileInputStream(fichero)) {
            return new String(leerTodo(in), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    /** Guarda el borrador (se llama solo cada vez que cambia algo). */
    @JavascriptInterface
    public boolean guardar(String id, String texto) {
        File fichero = borrador(id);
        File temporal = new File(fichero.getPath() + ".tmp");
        try (OutputStream out = new FileOutputStream(temporal)) {
            out.write(texto.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            return false;
        }
        return temporal.renameTo(fichero);
    }

    /**
     * Guarda un fichero que llega en base64 (el PDF o un config.json exportado) en Documentos/Elevadores/carpeta.
     * Si ya hay uno con ese nombre no se sustituye: Android le añade un número. Devuelve dónde ha quedado, o un
     * texto que empieza por "ERROR".
     */
    @JavascriptInterface
    public String guardarArchivo(String carpeta, String nombre, String tipo, String base64) {
        try {
            byte[] datos = Base64.decode(base64, Base64.DEFAULT);
            String limpio = nombre.replaceAll("[^A-Za-z0-9._-]", "_");
            String sub = CARPETA + "/" + (carpeta == null ? "otros" : carpeta.replaceAll("[^A-Za-z0-9_-]", "_"));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                return guardarEnDocumentos(sub, limpio, tipo, datos);
            }
            return guardarAntiguo(sub, limpio, datos);
        } catch (Exception e) {
            return "ERROR: " + e.getMessage();
        }
    }

    // Android 10 en adelante: en Documentos/Elevadores/..., sin pedir permisos.
    private String guardarEnDocumentos(String sub, String nombre, String tipo, byte[] datos) throws IOException {
        ContentValues valores = new ContentValues();
        valores.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        valores.put(MediaStore.MediaColumns.MIME_TYPE, tipo);
        valores.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/" + sub);
        ContentResolver resolver = contexto.getContentResolver();
        Uri uri = resolver.insert(MediaStore.Files.getContentUri("external"), valores);
        if (uri == null) {
            throw new IOException("Android no ha dejado crear el fichero.");
        }
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) {
                throw new IOException("Android no ha dejado escribir el fichero.");
            }
            out.write(datos);
        }
        // El nombre con el que ha quedado de verdad (si ya existía, Android le añade un número).
        String final_ = nombre;
        try (android.database.Cursor c = resolver.query(uri,
                new String[] {MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                final_ = c.getString(0);
            }
        }
        return "Documentos/" + sub + "/" + final_;
    }

    // Android 7 a 9: en Documentos/Elevadores/... si hay permiso; si no, en la carpeta de la aplicación.
    private String guardarAntiguo(String sub, String nombre, byte[] datos) throws IOException {
        File carpeta;
        boolean permiso = contexto.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
        if (permiso) {
            carpeta = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), sub);
        } else {
            carpeta = new File(contexto.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), sub);
        }
        if (!carpeta.isDirectory() && !carpeta.mkdirs()) {
            throw new IOException("No se puede crear la carpeta " + carpeta);
        }
        File fichero = new File(carpeta, nombre);
        int punto = nombre.lastIndexOf('.');
        for (int n = 2; fichero.exists(); n++) { // no se sustituye uno anterior
            fichero = new File(carpeta, punto > 0
                    ? nombre.substring(0, punto) + "_" + n + nombre.substring(punto) : nombre + "_" + n);
        }
        try (OutputStream out = new FileOutputStream(fichero)) {
            out.write(datos);
        }
        // Para que se vea enseguida al conectar la tableta por USB.
        MediaScannerConnection.scanFile(contexto, new String[] {fichero.getPath()}, null, null);
        return fichero.getPath();
    }

    private File borrador(String id) {
        String limpio = (id == null ? "formulario" : id).replaceAll("[^A-Za-z0-9_-]", "_");
        return new File(contexto.getFilesDir(), "borrador_" + limpio + ".json");
    }

    private static byte[] leerTodo(InputStream in) throws IOException {
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        byte[] trozo = new byte[8192];
        int n;
        while ((n = in.read(trozo)) != -1) {
            salida.write(trozo, 0, n);
        }
        return salida.toByteArray();
    }
}
