import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * Servidor para probar la aplicación en el ordenador, sin internet y sin instalar nada más que Java 11 o
 * posterior. Hace lo mismo que la parte Java de la APK: sirve la página, guarda los borradores y los PDF.
 *
 * Uso, desde la carpeta "elevadores":
 *   java escritorio/ServidorLocal.java          (puerto 8080)
 *   java escritorio/ServidorLocal.java 8081
 *
 * Abre http://localhost:8080/ en el navegador. Para recolocar los campos de un formulario:
 * http://localhost:8080/formulario.html?f=dos_columnas&editor=1
 * Los PDF van a salida/<carpeta del formulario> (2_columnas, 4_columnas) y los borradores a salida/borradores.
 */
public class ServidorLocal {

    private static final Map<String, String> TIPOS = Map.of(
            "html", "text/html; charset=utf-8", "js", "text/javascript; charset=utf-8",
            "css", "text/css; charset=utf-8", "json", "application/json; charset=utf-8",
            "jpg", "image/jpeg", "jpeg", "image/jpeg", "png", "image/png", "svg", "image/svg+xml");

    private static Path web;    // web/www: la aplicación entera (páginas y formularios)
    private static Path salida; // salida: lo que en la tableta va a Documentos/Elevadores

    public static void main(String[] args) throws IOException {
        Path raiz = Path.of("").toAbsolutePath();
        if (!Files.isDirectory(raiz.resolve("web"))) {
            raiz = raiz.getParent(); // por si se lanza desde dentro de "escritorio"
        }
        web = raiz.resolve("web/www");
        salida = raiz.resolve("salida");
        if (!Files.isDirectory(web)) {
            System.out.println("No encuentro " + web + ": lance el servidor desde la carpeta elevadores.");
            return;
        }
        Files.createDirectories(salida);
        int puerto = args.length > 0 ? Integer.parseInt(args[0]) : 8080;

        // Solo se atiende al propio ordenador.
        HttpServer servidor = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), puerto), 0);
        servidor.createContext("/api/borrador", ServidorLocal::borrador);
        servidor.createContext("/api/archivo", ServidorLocal::archivo);
        servidor.createContext("/", ServidorLocal::estatico);
        servidor.start();

        String url = "http://localhost:" + puerto + "/";
        System.out.println("Aplicación en " + url);
        System.out.println("Lo guardado va a " + salida);
        System.out.println("Pulse Ctrl+C para parar.");
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(URI.create(url));
            }
        } catch (Exception ignorado) {
            // sin navegador: se abre a mano
        }
    }

    // GET: las páginas y sus ficheros, de web/www.
    private static void estatico(HttpExchange ex) throws IOException {
        String ruta = ex.getRequestURI().getPath();
        if (ruta.equals("/")) {
            ruta = "/index.html";
        }
        Path fichero = web.resolve(ruta.substring(1)).normalize();
        if (!fichero.startsWith(web) || !Files.isRegularFile(fichero)) {
            responder(ex, 404, "text/plain; charset=utf-8", "No encontrado".getBytes(StandardCharsets.UTF_8));
            return;
        }
        String nombre = fichero.getFileName().toString();
        String ext = nombre.substring(nombre.lastIndexOf('.') + 1).toLowerCase();
        responder(ex, 200, TIPOS.getOrDefault(ext, "application/octet-stream"), Files.readAllBytes(fichero));
    }

    // GET: devuelve el borrador. POST: lo guarda.
    private static void borrador(HttpExchange ex) throws IOException {
        Path carpeta = salida.resolve("borradores");
        Path fichero = carpeta.resolve("borrador_" + seguro(parametros(ex).getOrDefault("id", "formulario")) + ".json");
        if ("POST".equals(ex.getRequestMethod())) {
            Files.createDirectories(carpeta);
            Path temporal = fichero.resolveSibling(fichero.getFileName() + ".tmp");
            Files.write(temporal, leer(ex));
            Files.move(temporal, fichero, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            responder(ex, 200, "text/plain; charset=utf-8", "ok".getBytes(StandardCharsets.UTF_8));
        } else if (Files.isRegularFile(fichero)) {
            responder(ex, 200, "application/json; charset=utf-8", Files.readAllBytes(fichero));
        } else {
            responder(ex, 200, "application/json; charset=utf-8", new byte[0]);
        }
    }

    // POST: guarda un fichero (PDF o config.json) que llega en base64 en salida/<carpeta>. Si ya hay uno con ese
    // nombre, no se sustituye: se añade _2, _3... Devuelve dónde ha quedado.
    private static void archivo(HttpExchange ex) throws IOException {
        String respuesta;
        try {
            Map<String, String> p = parametros(ex);
            String nombre = seguro(p.getOrDefault("nombre", "archivo"));
            byte[] datos = Base64.getDecoder().decode(new String(leer(ex), StandardCharsets.US_ASCII).trim());
            Path carpeta = salida.resolve(seguro(p.getOrDefault("carpeta", "otros")));
            Files.createDirectories(carpeta);
            Path fichero = libre(carpeta, nombre);
            Files.write(fichero, datos);
            respuesta = fichero.toString();
            System.out.println("Guardado " + fichero);
        } catch (Exception e) {
            respuesta = "ERROR: " + e.getMessage();
        }
        responder(ex, 200, "text/plain; charset=utf-8", respuesta.getBytes(StandardCharsets.UTF_8));
    }

    private static Path libre(Path carpeta, String nombre) {
        int punto = nombre.lastIndexOf('.');
        String base = punto > 0 ? nombre.substring(0, punto) : nombre;
        String ext = punto > 0 ? nombre.substring(punto) : "";
        Path fichero = carpeta.resolve(nombre);
        for (int n = 2; Files.exists(fichero); n++) {
            fichero = carpeta.resolve(base + "_" + n + ext);
        }
        return fichero;
    }

    private static String seguro(String nombre) {
        String limpio = nombre.replaceAll("[^A-Za-z0-9._-]", "_");
        return limpio.isEmpty() || limpio.startsWith(".") ? "archivo" + limpio : limpio;
    }

    private static Map<String, String> parametros(HttpExchange ex) {
        Map<String, String> mapa = new HashMap<>();
        String consulta = ex.getRequestURI().getRawQuery();
        if (consulta != null) {
            for (String par : consulta.split("&")) {
                int i = par.indexOf('=');
                if (i > 0) {
                    mapa.put(URLDecoder.decode(par.substring(0, i), StandardCharsets.UTF_8),
                            URLDecoder.decode(par.substring(i + 1), StandardCharsets.UTF_8));
                }
            }
        }
        return mapa;
    }

    private static byte[] leer(HttpExchange ex) throws IOException {
        try (InputStream in = ex.getRequestBody()) {
            return in.readAllBytes();
        }
    }

    private static void responder(HttpExchange ex, int codigo, String tipo, byte[] cuerpo) throws IOException {
        ex.getResponseHeaders().set("Content-Type", tipo);
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(codigo, cuerpo.length == 0 ? -1 : cuerpo.length);
        try (OutputStream out = ex.getResponseBody()) {
            out.write(cuerpo);
        }
    }
}
