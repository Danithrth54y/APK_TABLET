# Check-list de elevadores

Una sola aplicación para los tres elevadores: el **1** (4 columnas) y el **2** y el **3** (2 columnas). Al abrirla
se elige el elevador, se rellena su formulario sobre la imagen del propio formulario y se guarda en PDF. Funciona sin internet: primero en el
ordenador, para probar, y después como APK en la tableta.

## Qué hay en cada carpeta

| Carpeta | Qué es |
|---|---|
| `web/www` | La aplicación: la pantalla de inicio (`index.html`), la del formulario (`formulario.html`) y su código. |
| `web/www/formularios/lista.json` | Los elevadores que salen en la pantalla de inicio: número y formulario de cada uno. |
| `web/www/formularios/dos_columnas` | `config.json` (dónde va cada campo) y `fondo.jpg` (la imagen) del de 2 columnas. |
| `web/www/formularios/cuatro_columnas` | Lo mismo para el de 4 columnas. |
| `escritorio/ServidorLocal.java` | La parte Java para probar en el ordenador. |
| `android` | El proyecto de Android Studio que saca la APK. |

La imagen y las posiciones **no están en el código**: están en `config.json`, en fracciones del ancho y del alto de
la imagen (0 = borde izquierdo o superior, 1 = borde derecho o inferior). Así valen para cualquier pantalla y se
pueden cambiar sin programar.

## Qué hace

- Los cuadrados OK / DEFECTO de cada pregunta y día, y los tres de turno, son casillas: vacías o marcadas.
  **OK y DEFECTO del mismo día son excluyentes**, y también los tres turnos: al marcar una, se desmarca la otra.
- El resto son campos de texto: Nº de elevador, semana del / al, y Nombre+Apellido y Firma de cada día.
- Cada elevador tiene su propia hoja en curso, con su Nº ya puesto (no se puede cambiar). Lo que se escribe se guarda
  solo, al momento, y al volver a abrir ese elevador sigue igual.
- **Guardar PDF** pregunta el nombre del fichero con uno ya propuesto, que se puede cambiar:
  - Elevador 1: `4_1_columnas_<semana del>`, por ejemplo `4_1_columnas_23-11-2026.pdf`
  - Elevador 2: `2_2_columnas_23-11-2026.pdf`
  - Elevador 3: `2_3_columnas_23-11-2026.pdf`

  Si ya existe un PDF con ese nombre, no se sustituye: se guarda con `_2`, `_3`… al final.
- **Nuevo formulario** vacía la hoja de ese elevador (pide confirmación y conserva el Nº) para empezar otra semana.

## Dónde se guarda cada cosa

| Qué | En la tableta | En el ordenador (prueba) |
|---|---|---|
| PDF de los elevadores 2 y 3 | `Documentos/Elevadores/2_columnas` | `salida/2_columnas` |
| PDF del elevador 1 | `Documentos/Elevadores/4_columnas` | `salida/4_columnas` |
| Lo que se va escribiendo (borrador) | dentro de la aplicación (no se ve) | `salida/borradores` |

Al conectar la tableta al ordenador por USB (modo *Transferencia de archivos*) se ve la carpeta
`Documentos/Elevadores`. En Android 7 a 9 la aplicación pide permiso de almacenamiento la primera vez; si se deniega,
los PDF van a `Android/data/es.elevadores.checklist/files/Documents/Elevadores`.

El formato del nombre se cambia en `config.json`, en `nombrePdf`: cada `{campo}` se sustituye por lo escrito en ese
campo. La carpeta, en `carpeta`.

## 1. Probar en el ordenador

Hace falta Java 11 o posterior. Desde la carpeta `elevadores`:

```
java escritorio/ServidorLocal.java
```

Se abre el navegador en `http://localhost:8080/`.

## 2. Sacar la APK sin instalar nada (con GitHub)

GitHub hace la APK en sus servidores; solo hace falta un navegador.

1. Crear una cuenta gratuita en github.com.
2. Arriba a la derecha, **+ › New repository**. Nombre: `checklist-elevadores`. Marcar **Private** y pulsar
   **Create repository**.
3. En la página que aparece, pulsar el enlace **uploading an existing file**. Arrastrar a esa página **todo lo que
   hay dentro** de la carpeta `elevadores` (no la carpeta en sí) y pulsar **Commit changes**.
4. Comprobar que en el repositorio aparece la carpeta `.github`. Si no aparece (en Mac las carpetas que empiezan
   por punto están ocultas): **Add file › Create new file**, escribir como nombre `.github/workflows/apk.yml`,
   pegar el contenido de ese fichero y pulsar **Commit changes**.
5. Pestaña **Actions**: se está haciendo la APK (círculo amarillo). Tarda unos 5 minutos; cuando acaba sale un
   tic verde.
6. En la página principal del repositorio, a la derecha, **Releases**: en la última está `CheckListElevadores.apk`.

Cada vez que se sube un cambio, se hace una APK nueva sola. También se puede lanzar a mano:
**Actions › Generar APK › Run workflow**.

Alternativa sin GitHub: instalar Android Studio, abrir la carpeta `android` y **Build › Build APK(s)**.

## 3. Instalar en la tableta

- **Desde la tableta (con internet):** entrar en github.com con la misma cuenta, abrir el repositorio,
  **Releases** y tocar `CheckListElevadores.apk` para descargarla.
- **O por USB:** descargarla en el ordenador, conectar la tableta (modo *Transferencia de archivos*) y copiarla a
  la carpeta *Download*.

Después, en la tableta: **Archivos › Descargas** y tocar `CheckListElevadores.apk`. La primera vez Android pide
permitir *instalar aplicaciones de origen desconocido* para el navegador o para Archivos: aceptar, volver atrás y
pulsar **Instalar**. Aparece como «Check-list elevadores».

Para actualizarla, se instala la APK nueva encima de la anterior: no hace falta desinstalar y se conservan las
hojas en curso. Funciona porque todas las APK llevan la misma firma (`android/app/firma.jks`). Si se pierde ese
fichero, la siguiente APK no se podrá instalar encima.

## 4. Si cambian las preguntas o la imagen

- **Solo cambia el texto**, con las casillas en el mismo sitio: basta con sustituir `fondo.jpg`, siempre que la
  imagen nueva tenga el mismo encuadre.
- **Cambia la posición de los campos o el encuadre:** abrir en el ordenador
  `http://localhost:8080/formulario.html?f=dos_columnas&editor=1` (o `cuatro_columnas`):
  - arrastrar un campo con el ratón, o seleccionarlo y moverlo con las flechas (Mayús = 10 píxeles a la vez);
  - Ctrl + flechas cambia su tamaño;
  - con «Mover todo su grupo» se mueve todo el grupo a la vez (la rejilla de casillas, los seis nombres…);
  - **Exportar config.json** lo guarda en `salida/config_<formulario>`; copiarlo a `web/www/formularios/<formulario>`
    y volver a sacar la APK.
- **Hay una pregunta más o menos:** añadir o quitar en `config.json` las líneas de esa fila (copiar las de otra y
  cambiar `id`, `excluye` e `y`) y ajustarlas con el editor.
- **Un elevador más de un tipo que ya existe:** una línea más en `lista.json` con su número.
- **Un formulario nuevo:** otra carpeta en `web/www/formularios` con su `config.json` y su imagen, y su línea en
  `lista.json`.

Tipos de campo en `config.json`: `check` (casilla), `texto` (una línea) y `multilinea` (varias líneas, para nombre y
firma). Las casillas con el mismo `excluye` no pueden estar marcadas a la vez.
